/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab999;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Lab999 extends Application {

    
    int a = 0;
    @Override
    public void start(Stage primaryStage) {
        HBox n = new HBox();
        n.setSpacing(10);
        n.setAlignment(Pos.CENTER);

        Label word = new Label("Word :");
        TextField txtWord = new TextField();
        Label result = new Label("Result :");
        TextField txtResult = new TextField();
        n.getChildren().addAll(word, txtWord, result, txtResult);

        Button length = new Button("Length Word");
        length.setOnAction(e -> {
            a = txtWord.getText().length();
            txtResult.setText(a + "");
        });
        Button vowels = new Button("Number Vowels");
        vowels.setOnAction(e -> {
            int count = 0;
            for (int i = 0; i < txtWord.getText().length(); i++) {
                if (Character.toLowerCase(txtWord.getText().charAt(i)) == 'a' || Character.toLowerCase(txtWord.getText().charAt(i)) == 'e' || Character.toLowerCase(txtWord.getText().charAt(i)) == 'i' || Character.toLowerCase(txtWord.getText().charAt(i)) == 'o' || Character.toLowerCase(txtWord.getText().charAt(i)) == 'u') {
                    count++;
                }
            }
            a = count;
            txtResult.setText(a + "");
        });
        Button upperCase = new Button("Number UpperCase");
        upperCase.setOnAction(e -> {
            int count = 0;
            for (int i = 0; i < txtWord.getText().length(); i++) {
                if (Character.isUpperCase(txtWord.getText().charAt(i))) {
                    count++;
                }
            }
            a = count;
            txtResult.setText(a + "");
        });
        HBox pane = new HBox();
        pane.setSpacing(10);
        pane.setAlignment(Pos.CENTER);
        pane.getChildren().addAll(length, vowels, upperCase);

        BorderPane borderPane = new BorderPane(n);
        BorderPane.setMargin(n, new Insets(10, 10, 10, 10));
        borderPane.setBottom(pane);
        BorderPane.setMargin(pane, new Insets(10, 10, 10, 10));
        primaryStage.setScene(new Scene(borderPane));
        primaryStage.setTitle("Word");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
