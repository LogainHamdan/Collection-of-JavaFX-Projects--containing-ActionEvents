

package lab9999;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Lab9999 extends Application {

    double answer = 0;

    @Override
    public void start(Stage primaryStage) {

        HBox n = new HBox();
        n.setSpacing(10);
        n.setAlignment(Pos.CENTER);

        Label label1 = new Label("Number 1:");
        TextField txt1 = new TextField();

        Label label2 = new Label("Number 2:");
        TextField txt2 = new TextField();
        

        Label result = new Label("Result :");
        
        txt2.setMinSize(50, 50);
        txt1.setMinSize(50, 50);
        TextField txt3 = new TextField();
        txt3.setMinSize(50, 50);
    
        n.getChildren().addAll(label1, txt1, label2, txt2, result, txt3);
        
        Button add = new Button("Add");
        add.setOnAction(e -> {
            answer = Double.parseDouble(txt1.getText()) + Double.parseDouble(txt2.getText());
            txt3.setText(answer + "");
        });
    
        Button subtract = new Button("Subtract");
        subtract.setOnAction(e -> {
            answer = Double.parseDouble(txt1.getText()) - Double.parseDouble(txt2.getText());
            txt3.setText(answer + "");
        });
        Button multi = new Button("Multiply");
        multi.setOnAction(e -> {
            answer = Double.parseDouble(txt1.getText()) * Double.parseDouble(txt2.getText());
            txt3.setText(answer + "");
        });
        Button divide = new Button("Divide");
        divide.setOnAction(e -> {
            answer = Double.parseDouble(txt1.getText()) / Double.parseDouble(txt2.getText());
            txt3.setText(answer + "");
        });

        HBox pane = new HBox();
        pane.setSpacing(10);
        pane.setAlignment(Pos.CENTER);
        pane.getChildren().addAll(add, subtract, multi, divide);

        BorderPane borderPane = new BorderPane(n);
        BorderPane.setMargin(n, new Insets(5, 5, 5, 5));
        borderPane.setBottom(pane);
        BorderPane.setMargin(pane, new Insets(5, 5, 5, 5));
        primaryStage.setScene(new Scene(borderPane));
        primaryStage.setTitle("Exercise15_04");
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}

