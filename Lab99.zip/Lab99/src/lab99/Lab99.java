/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab99;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Lab99 extends Application {

    Label guess = new Label("Guess Number:");
    TextField txtGuess = new TextField();
    Label result = new Label();
    int n = (int) (Math.random() * 101);

    @Override
    public void start(Stage primaryStage) {
        BorderPane pane = new BorderPane();
        pane.setPadding(new Insets(10, 10, 10, 10));

        pane.setCenter(getHBox1());
        pane.setTop(getHBox2());
        pane.setBottom(getHBox3());

        Scene scene = new Scene(pane);
        primaryStage.setTitle("Guessing Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private HBox getHBox1() {
        HBox hBox = new HBox(10);
        hBox.setPadding(new Insets(10, 10, 20, 10));
        Button check = new Button("Check");
        check.setOnAction(e -> {
            int GuessNumber = Integer.parseInt(txtGuess.getText());
            if (GuessNumber == n) {
                result.setText("True :))");
            } else if (GuessNumber > n) {
                result.setText("Too high");
            } else {
                result.setText("Too Low");
            }
        });
        hBox.getChildren().add(check);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        return hBox;
    }

    private HBox getHBox2() {
        HBox hBox = new HBox(10);
        hBox.setPadding(new Insets(10, 10, 10, 10));

        hBox.getChildren().add(guess);
        hBox.getChildren().add(txtGuess);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        return hBox;
    }

    private HBox getHBox3() {
        HBox hBox = new HBox(10);
        hBox.setPadding(new Insets(10, 10, 10, 10));

        hBox.getChildren().add(result);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        return hBox;
    }

    public static void main(String[] args) {
        launch(args);
    }
}





