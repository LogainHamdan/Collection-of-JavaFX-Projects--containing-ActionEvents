/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class p1 extends Application {

    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(20, 20, 20, 20));
        pane.setHgap(15);
        pane.setVgap(10);

        pane.add(new Label("First Name:"), 0, 0);
        pane.add(new TextField(), 1, 0);
        pane.add(new Label("Last Name:"), 0, 1);
        pane.add(new TextField(), 1, 1);
        Label city = new Label("City:");
        GridPane.setHalignment(city, HPos.RIGHT);
        pane.add(city, 0, 2);
        pane.add(new TextField(), 1, 2);
        Label str1 = new Label("Street/Nr.:");
        pane.add(str1, 0, 3);
        GridPane.setHalignment(str1, HPos.RIGHT);
        TextField str2 = new TextField();
        str2.setPrefColumnCount(15);
        GridPane.setColumnSpan(str2, 2);
        pane.add(str2, 1, 3);
        GridPane.setHalignment(str2, HPos.RIGHT);
        Label n1 = new Label("Notes:");
        GridPane.setHalignment(n1, HPos.RIGHT);
        pane.add(n1, 0, 4);
        TextArea n2 = new TextArea();
        GridPane.setColumnSpan(n2, 3);
        GridPane.setRowSpan(n2, 2);
        pane.add(n2, 1, 4);

        Button log = new Button("Login");
        pane.add(log, 3, 3);
        GridPane.setHalignment(log, HPos.RIGHT);

        ImageView img = new ImageView("https://www.clickexchange.ca/wp-content/uploads/2021/04/OK_1.png");
        img.setFitHeight(100);
        img.setFitWidth(100);
        GridPane.setHalignment(img, HPos.RIGHT);
        pane.add(img, 2, 0);
        GridPane.setColumnSpan(img, 2);
        GridPane.setRowSpan(img, 3);
        Scene scene = new Scene(pane, 450, 450);

        primaryStage.setTitle("JavaFx-Example1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}


