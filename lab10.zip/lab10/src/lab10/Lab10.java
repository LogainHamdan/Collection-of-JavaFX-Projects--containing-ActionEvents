/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Lab10 extends Application {

    TextField num1TextField;
    TextField num2TextField;
    TextField num3TextField;

    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        VBox vbox = new VBox(20);
        HBox hLabels = new HBox(10);
        HBox hTextField = new HBox(10);
        HBox hButtons = new HBox(10);
        vbox.getChildren().addAll(hLabels, hTextField, hButtons);

        Label num1Label = new Label("Number: ");
        Label num2Label = new Label("Number: ");
        Label num3Label = new Label("Number: ");
        hLabels.getChildren().addAll(num1Label, num2Label, num3Label);

        StackPane root = new StackPane();
        Scene scene = new Scene(vbox, 300, 250);

        hTextField.getChildren().addAll(num1TextField, num2TextField, num3TextField);

        Button addBtn = new Button();
        Button subBtn = new Button();
        Button mulBtn = new Button();
        Button divBtn = new Button();
        hButtons.getChildren().addAll(addBtn, subBtn, mulBtn, divBtn);
        addBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                num1TextField.getText();
            }
        });

        Image i = new Image("file:D:\\Logein\\Images\\ll");

    }

    public static void main(String[] args) {
        launch(args);
    }

}
