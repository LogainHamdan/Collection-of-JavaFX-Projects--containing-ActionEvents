package hw12;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

public class F33 {

    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        String line;
        int count = 0;
        System.out.println("Enter file name: ");
        FileReader file = new FileReader(input.nextLine());
        try (BufferedReader b = new BufferedReader(file)) {
            while ((line = b.readLine()) != null) {
                String words[] = line.split(" ");
                count = count + words.length;
            }

            System.out.println("Number of words: " + count);
        }
    }
}

