/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw12;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class F1 {

    public static void main(String[] args)  {

        Scanner input = new Scanner(System.in);
        System.out.print("Enter file: ");
        File file = new File(input.nextLine());

        if (!file.exists()) {
            System.out.println("File " + file + " doesn't exist");
            System.exit(1);
        }
        
        int count = 0;
        double total = 0;

        try (Scanner inputFile = new Scanner(file)) {
            while (inputFile.hasNext()) {
                total += inputFile.nextInt();
                count++;
            }
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
        
        System.out.println("File: " + file.getName());
        System.out.println("Total: " + total);
        System.out.println("Average: " + (total*1.0 / count));
    }
}

