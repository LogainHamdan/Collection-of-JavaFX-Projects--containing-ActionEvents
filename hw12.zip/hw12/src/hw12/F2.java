package hw12;

import java.util.*;
import java.io.*;

public class F2 {

    public static void main(String[] args) throws Exception {

        File file = new File("MyFile.txt");
        if (file.exists()) {
            System.out.println("Exists");
            System.exit(0);
        }

        try (PrintWriter output = new PrintWriter(file)) {
            for (int i = 0; i < 100; i++) {
                output.print((int) (Math.random()*100));
                output.print(" ");
            }
        }
        ArrayList<Integer> list = new ArrayList<>();
        try (Scanner input = new Scanner(file)) {
            while (input.hasNext()) {
                list.add(input.nextInt());
            }
        }
       
        Collections.sort(list);
     
        System.out.print(list.toString());
        System.out.println();
    }
}
